﻿namespace LibraryAPI_R53_A.DTOs.Account
{
    #region step 07
    public class UserDto
    {
        public string UserName { get; set; }
        public string JWT { get; set; }
    }
    #endregion 
}
