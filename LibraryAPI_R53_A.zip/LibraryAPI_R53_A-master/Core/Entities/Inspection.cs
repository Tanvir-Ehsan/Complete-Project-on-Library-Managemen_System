﻿//using System.Text.Json.Serialization;

//namespace LibraryAPI_R53_A.Core.Domain
//{
//    public class Inspection
//    {
//        public int InspectionId { get; set; }
//        public string? Comment { get; set; }
//        //public bool IsActive { get; set; }
//        public int BookCopyId { get; set; }
//        [JsonIgnore]
//        public BookCopy? BookCopy { get; set; }
//        public int BorrowBookId { get; set; }
//        [JsonIgnore]
//        public BorrowedBook? BorrowedBook { get; set; }
//    }
//}
////extra fine will be added to user based on condition checking manually and comment property will include that extra details
