﻿using LibraryAPI_R53_A.Core.Domain;

namespace LibraryAPI_R53_A.Core.Repositories
{
    public interface IPublisher:IRepository<Publisher>
    {
       

    }
}
